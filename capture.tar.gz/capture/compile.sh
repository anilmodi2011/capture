make telosb;
make telosb install,1 bsl,/dev/ttyUSB0;
make telosb install,2 bsl,/dev/ttyUSB1;
make telosb install,3 bsl,/dev/ttyUSB2;
